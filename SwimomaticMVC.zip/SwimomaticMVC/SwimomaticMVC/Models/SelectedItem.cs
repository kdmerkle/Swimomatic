﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class SelectedItem
    {
        public bool IsChecked { get; set; }
        public int ItemID  { get; set; }
    }
}