﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewHeatSheetEvents
    {
        public int HeatSheetID { get; set; }

        private List<ViewHeatSheetEvent> _ViewHeatSheetEventList;
        public List<ViewHeatSheetEvent> ViewHeatSheetEventList
        {
            get
            {
                if (_ViewHeatSheetEventList == null)
                {
                    _ViewHeatSheetEventList = new List<ViewHeatSheetEvent>();
                }
                return _ViewHeatSheetEventList;
            }
            set { _ViewHeatSheetEventList = value; }
        }
    }
}
