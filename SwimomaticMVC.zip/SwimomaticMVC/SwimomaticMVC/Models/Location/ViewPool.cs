﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewPool :ViewPoolConfig
    {
        public string PoolDescription { get; set; }
    }
}