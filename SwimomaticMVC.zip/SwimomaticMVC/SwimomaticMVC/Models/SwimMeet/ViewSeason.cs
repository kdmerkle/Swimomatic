﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SwimomaticMVC.Models
{
    public class ViewSeason
    {
        public int SeasonID { get; set; }
        public int TeamSeasonID { get; set; }
        public int LeagueID { get; set; }
        public string LeagueName { get; set; }
        public string LeagueDescription { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }

        public int AgeClassRuleID { get; set; }
        public DateTime AgeClassRuleCustomDate { get; set; }
        public SelectList AgeClassRules { get; set; }

        public List<int> ScoringSchemeIDs { get; set; }
        public string ScoringCustomIndividual { get; set; }
        public string ScoringCustomRelay { get; set; }
        public List<ViewScoringScheme> ScoringSchemesHeat { get; set; }
        public List<ViewScoringScheme> ScoringSchemesFinal { get; set; }
        public List<ViewScoringScheme> ScoringSchemesConsolation { get; set; }

    }
}