﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewSwimMeet
    {
        public int SwimMeetID { get; set; }
        public bool CanEdit { get; set; }
        public bool HasResults{ get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public int LocationID { get; set; }
        public string LocationName { get; set; }
        public int LeagueID { get; set; }
        public string LeagueDescription { get; set; }
        public string LeagueName { get; set; }
        public int SeasonID { get; set; }
        public string SeasonDescription { get; set; }
        public string Teams { get; set; }
    }
}
