﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewSwimEvent
    {
        public string StrokeDescription { get; set; }
        public string AgeClassDescription { get; set; }
    }
}
