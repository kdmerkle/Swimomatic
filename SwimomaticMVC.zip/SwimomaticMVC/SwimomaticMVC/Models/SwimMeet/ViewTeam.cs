﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;

namespace SwimomaticMVC.Models
{
    public class ViewTeam
    {
        public int TeamID { get; set; }
        [DisplayName("Team")]
        public string TeamName { get; set; }
        public string Abbrev { get; set; }
        public string TeamNameAbbrev { get; set; }

        //Location
        public string Address { get; set; }
        public string City { get; set; }
        public int LocationID { get; set; }
        public string LocationName { get; set; }
        public string PostalCode { get; set; }

        [DisplayName("State")]
        public int RegionID { get; set; }

        //Season
        public int TeamSeasonID { get; set; }
        public int SeasonID { get; set; }
        public string SeasonDescription { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string LeagueName { get; set; }

        public int UserSwimmerID { get; set; }
        public int TeamLeagueRequestID { get; set; }
        public int UserTeamID { get; set; }

        private List<ViewSwimmer> _SwimmerTeamSeasonList;
        public List<ViewSwimmer> SwimmerTeamSeasonList
        {
            get
            {
                if (_SwimmerTeamSeasonList == null)
                {
                    _SwimmerTeamSeasonList = new List<ViewSwimmer>();
                }
                return _SwimmerTeamSeasonList;
            }
            set { _SwimmerTeamSeasonList = value; }
        }

        private List<ViewSwimmer> _SwimmerTeamRequestList;
        public List<ViewSwimmer> SwimmerTeamRequestList
        {
            get
            {
                if (_SwimmerTeamRequestList == null)
                {
                    _SwimmerTeamRequestList = new List<ViewSwimmer>();
                }
                return _SwimmerTeamRequestList;
            }
            set { _SwimmerTeamRequestList = value; }
        }

    }
}