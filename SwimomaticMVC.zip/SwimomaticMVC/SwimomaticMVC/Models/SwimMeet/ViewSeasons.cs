﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewSeasons
    {
        private List<ViewSeason> _ViewSeasonList;
        public List<ViewSeason> ViewSeasonList
        {
            get
            {
                if (_ViewSeasonList == null)
                {
                    _ViewSeasonList = new List<ViewSeason>();
                }
                return _ViewSeasonList;
            }
            set
            {
                _ViewSeasonList = value;
            }
        }
    }
}