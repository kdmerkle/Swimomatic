﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SwimomaticMVC.Models
{
    public class ViewHeatSheetEventResult
    {
        public int HeatSwimmerID { get; set; }
        public double ElapsedTime { get; set; }
        public double Split { get; set; }
        public bool Disqualified { get; set; }
    }
}