﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SwimomaticMVC.Models;
using SwimomaticBusinessLib;
using Swimomatic.Entity;
using SwimomaticMVC.Helpers;
using LAAF.Logger;
using Helpers;

namespace SwimomaticMVC.Controllers
{
    public class ControllerBase : Controller
    {
        #region Properties
        private SwimomaticBusinessManager _BizMgr;
        internal SwimomaticBusinessManager BizMgr
        {
            get
            {
                if (_BizMgr == null)
                {
                    _BizMgr = new SwimomaticBusinessManager();
                }
                return _BizMgr;
            }
        }

        public CurrentUserBase CurrentUser
        {
            get
            {
                return (CurrentUserBase)Session["CurrentUser"];
            }
            set
            {
                Session["CurrentUser"] = value;
            }
        }

        #endregion

        #region Event Handlers
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (CurrentUser != null)
                filterContext.Controller.ViewData["Username"] = CurrentUser.UserName;
            else
                filterContext.Controller.ViewData["Username"] = "";
            base.OnActionExecuting(filterContext);
        }
        #endregion

        #region Methods

        #region Action Methods
        /// <summary>
        /// Return a merged set of User's Locations and Searched Locations if Merge=1
        /// Else, returns Locations By City & Region
        /// </summary>
        /// <param name="RegionID"></param>
        /// <param name="City"></param>
        /// <returns></returns>
        public ActionResult LocationSearch(int RegionID, string City, int Merge)
        {
            try
            {
                bool bMerge = Convert.ToBoolean(Merge);
                List<ViewLocation> vls = new List<ViewLocation>();
                LocationCollection ls = BizMgr.GetLocationsByCityRegionID(City, RegionID);
                LocationCollection uls = new LocationCollection();
                if (bMerge)
                {
                    uls = BizMgr.GetLocationsBySystemUserID(this.CurrentUser.SystemUserID);
                }
                LocationCollection unionLS = LAAF.Common.Helper.Union(uls, ls, "LocationID");
                string[] arrSort = new string[] { "RegionAbbrev", "City" };
                unionLS.Sort(arrSort, LAAF.Common.Helper.SortDirection.Ascending);
                ViewData["Locations"] = GetViewLocationsFromLocations(unionLS);
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + this.CurrentUser.SystemUserID.ToString(), "");
            }
            return PartialView("Locations");
        }

        #endregion

        /// <summary>
        /// Gets list of all regions to populate dropdown list
        /// </summary>
        /// <returns></returns>
        protected SelectList GetRegions(int RegionID)
        {
            RegionCollection regions = BizMgr.GetRegions();
            if (RegionID > 0)
            {
                return new SelectList(regions, "RegionID", "RegionName", RegionID);
            }
            else
            {
                return new SelectList(regions, "RegionID", "RegionName");
            }
        }

        protected SelectList GetUOMs(int UOMID)
        {
            UOMCollection uoms = BizMgr.GetUOMs();
            if (UOMID > 0)
            {
                return new SelectList(uoms, "UOMID", "Description", UOMID);
            }
            else
            {
                return new SelectList(uoms, "UOMID", "Description");
            }
        }

        private List<ViewLocation> GetViewLocationsFromLocations(LocationCollection ls)
        {
            List<ViewLocation> vls = new List<ViewLocation>();
            ViewLocation vl;
            foreach (Location l in ls)
            {
                vl = new ViewLocation();
                vl.LocationID = l.LocationID;
                vl.Address = l.Address;
                vl.City = l.City;
                vl.Name = l.Name;
                vl.PoolCount = l.PoolCount;
                vl.PostalCode = l.PostalCode;
                vl.RegionAbbrev = l.RegionAbbrev;
                vls.Add(vl);
            }
            return vls;
        }

        public List<ViewLocation> GetViewLocations(int SystemUserID)
        {
            //TODO: Determine whether SystemUserID is neccessary
            LocationCollection ls = BizMgr.GetLocationsBySystemUserID(this.CurrentUser.SystemUserID);
            return GetViewLocationsFromLocations(ls);
        }

        protected List<ViewHeat> GetHeats(int HeatSheetEventID)
        {
            List<ViewHeat> vhs = new List<ViewHeat>();
            ViewHeat vh;
            HeatCollection heats = BizMgr.GetHeatsByHeatSheetEventID(HeatSheetEventID);

            int laneCount = 1;
            bool isRelay = false;
            if (heats.Count > 0)
            {
                PoolConfig poolConfig = BizMgr.GetPoolConfigByHeatID(heats[0].HeatID);
                laneCount = poolConfig.LaneCount;
                Stroke stroke = BizMgr.GetStrokeByHeatID(heats[0].HeatID);
                isRelay = stroke.IsRelay;
            }

            List<ViewHeatSwimmer> vhss = new List<ViewHeatSwimmer>();
            foreach (Heat heat in heats)
            {
                vh = new ViewHeat();
                vh.HeatID = heat.HeatID;
                vh.HeatNumber = heat.HeatNumber;
                vh.LaneCount = laneCount;
                vh.IsRelay = isRelay;
                vh.HeatSheetEventID = heat.HeatSheetEventID;
                vhss = GetHeatSwimmers(heat.HeatID);
                if (vhss.Count > 0)
                {
                    vh.ViewHeatSwimmers.AddRange(vhss);
                }
                vhs.Add(vh);
            }
            return vhs;
        }

        private List<ViewHeatSwimmer> GetHeatSwimmers(int HeatID)
        {
            List<ViewHeatSwimmer> vhss = new List<ViewHeatSwimmer>();
            ViewHeatSwimmer vhs;
            PoolConfig pc = null;
            Result r = null;
            HeatSwimmerCollection heatSwimmers = BizMgr.GetHeatSwimmersByHeatID(HeatID);
            foreach (HeatSwimmer heatSwimmer in heatSwimmers)
            {
                vhs = new ViewHeatSwimmer();
                vhs.LaneNumber = heatSwimmer.LaneNumber;
                vhs.Leg = heatSwimmer.Leg;
                vhs.LastFirstName = heatSwimmer.LastFirstName;
                vhs.Disqualified = heatSwimmer.Disqualified;
                vhs.ElapsedTime = heatSwimmer.ElapsedTime;
                vhs.Place = heatSwimmer.Place;
                vhs.Points = heatSwimmer.Points;

                if (pc == null)
                {
                    pc = BizMgr.GetPoolConfigByHeatSheetEventID(heatSwimmer.HeatSheetEventID);
                }

                //TODO:Figure out what to do if event is seeded by split instead of ET
                r = BizMgr.GetResult(heatSwimmer.SeedResultID);
                vhs.SeedTime = BizMgr.GetConvertedTime(r.LaneLength, r.UOMID, r.ElapsedTime, pc.LaneLength, pc.UOMID);
                vhs.Split = heatSwimmer.Split;
                vhs.TeamNameAbbrev = heatSwimmer.Abbrev;
                vhs.HeatSwimmerID = heatSwimmer.HeatSwimmerID;
                vhss.Add(vhs);
            }

            return vhss;
        }

        #endregion

    }
}