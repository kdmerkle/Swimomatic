﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SwimomaticMVC.Models;
using Swimomatic.Entity;
using SwimomaticBusinessLib;
using LAAF.Logger;

namespace SwimomaticMVC.Controllers
{
    public class LeagueController : ControllerBase
    {

        #region Action Methods
        public ActionResult Index()
        {
            ViewData["Leagues"] = GetLeagues();
            return View();
        }
        public PartialViewResult League(int LeagueID)
        {
            ViewData["League"] = GetLeague(LeagueID);
            return PartialView("League");
        }
        public PartialViewResult Seasons(int LeagueID)
        {
            ViewData["Seasons"] = GetSeasons(LeagueID);
            ViewData["LeagueID"] = LeagueID;
            return PartialView("Seasons");
        }
        public PartialViewResult TeamSeasons(int SeasonID)
        {
            ViewData["TeamSeasons"] = GetTeamSeasons(SeasonID);
            return PartialView("TeamSeasons");
        }
        public PartialViewResult Season(int SeasonID, int LeagueID)
        {
            ViewData["Season"] = GetSeason(SeasonID, LeagueID);
            return PartialView("Season");
        }
        public PartialViewResult TeamLeagueRequests(int SeasonID)
        {
            ViewData["TeamLeagueRequests"] = GetTeamLeagueRequests(SeasonID);
            return PartialView("TeamLeagueRequests");
        }
        public PartialViewResult ApproveRequest(int TeamLeagueRequestID, int SeasonID)
        {
            BizMgr.ApproveTeamLeagueRequest(TeamLeagueRequestID, this.CurrentUser.SystemUserID);
            ViewData["TeamLeagueRequests"] = GetTeamLeagueRequests(SeasonID);
            return PartialView("TeamLeagueRequests");
        }

        [HttpPost]
        public PartialViewResult SaveLeague(ViewLeague model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    League league = new League();
                    league.LeagueID = model.LeagueID;
                    league.LeagueName = model.LeagueName;
                    league.RegionID = model.RegionID;
                    model.LeagueID = BizMgr.SaveLeague(league);
                    BizMgr.SaveUserLeague(model.LeagueID, this.CurrentUser.SystemUserID);
                }
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "League=" + model.LeagueID.ToString());
            }
            ViewData["Leagues"] = GetLeagues();
            return PartialView("LeagueList");
        }

        public PartialViewResult SaveSeason(int SeasonID, int LeagueID, string Description, DateTime StartDate, DateTime EndDate, string ScoringSchemeIDs, int AgeClassRuleID, string ScoringCustomIndividual, string ScoringCustomRelay, DateTime AgeClassRuleCustomDate)
        {
            Season season = BizMgr.GetSeason(SeasonID);
            try
            {
                season.AgeClassRuleID = AgeClassRuleID;
                season.AgeClassRuleCustomDate = (AgeClassRuleID > 0) ? AgeClassRuleCustomDate : DateTime.MinValue;
                season.LeagueID = LeagueID;
                season.Description = Description;
                season.StartDate = StartDate;
                season.EndDate = EndDate;
                season.SeasonID = BizMgr.SaveSeason(season);

                //Delete existing SeasonScoringSchemes
                BizMgr.DeleteSeasonScoringSchemesBySeasonID(season.SeasonID);

                //USASwimming Scoring Schemes
                System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<ScoringScheme> scoringSchemes = new List<ScoringScheme>();
                scoringSchemes = js.Deserialize<List<ScoringScheme>>(ScoringSchemeIDs);
                SeasonScoringScheme sss = null;
                foreach (ScoringScheme scoringScheme in scoringSchemes)
                {
                    sss = new SeasonScoringScheme();
                    sss.SeasonID = season.SeasonID;
                    sss.ScoringSchemeID = scoringScheme.ScoringSchemeID;
                    BizMgr.SaveSeasonScoringScheme(sss);
                }

                //Custom Scoring Schemes
                if (!ScoringCustomIndividual.Equals("0"))
                {
                    //TODO: Add input validation for custom scoring schemes:  regex for "8,7,6,5,4" and both relay & indidvidual required
                    int CustomScoringSchemeID = BizMgr.SaveScoringScheme(ScoringCustomIndividual, ScoringCustomRelay);
                    sss = new SeasonScoringScheme();
                    sss.SeasonID = season.SeasonID;
                    sss.ScoringSchemeID = CustomScoringSchemeID;
                    BizMgr.SaveSeasonScoringScheme(sss);
                }

            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "Season=" + season.SeasonID.ToString());
            }
            ViewData["Seasons"] = GetSeasons(season.LeagueID);
            ViewData["LeagueID"] = season.LeagueID;
            return PartialView("Seasons");
        }
        #endregion

        #region Private Methods
        private List<ViewLeague> GetLeagues()
        {
            LeagueCollection leagues = BizMgr.GetLeaguesBySystemUserID(this.CurrentUser.SystemUserID);
            List<ViewLeague> vls = new List<ViewLeague>();
            ViewLeague vl;
            foreach (League league in leagues)
            {
                vl = new ViewLeague();
                vl.LeagueName = league.LeagueName;
                vl.RegionID = league.RegionID;
                vl.LeagueDescription = league.Description;
                vl.LeagueID = league.LeagueID;
                vl.RegionAbbrev = league.RegionAbbrev;
                vls.Add(vl);
            }
            return vls;
        }
        private List<ViewLeague> GetSeasons(int LeagueID)
        {
            SeasonCollection seasons = BizMgr.GetSeasonsByLeagueID(LeagueID);
            List<ViewLeague> vls = new List<ViewLeague>();
            ViewLeague vl;
            foreach (Season season in seasons)
            {
                vl = new ViewLeague();
                vl.LeagueDescription = season.Description;
                vl.LeagueID = season.LeagueID;
                vl.SeasonID = season.SeasonID;
                vl.StartDate = season.StartDate;
                vl.EndDate = season.EndDate;
                vls.Add(vl);
            }
            return vls;
        }

        private ViewLeague GetLeague(int LeagueID)
        {
            League league = BizMgr.GetLeague(LeagueID);
            ViewLeague vl = new ViewLeague();
            vl.LeagueName = league.LeagueName;
            vl.RegionID = league.RegionID;
            vl.Regions = GetRegions(league.RegionID);
            vl.LeagueDescription = league.Description;
            vl.LeagueID = league.LeagueID;
            vl.RegionAbbrev = league.RegionAbbrev;
            return vl;
        }
        private ViewSeason GetSeason(int SeasonID, int LeagueID)
        {
            Season season = BizMgr.GetSeason(SeasonID);
            ViewSeason vs = new ViewSeason();
            vs.Description = season.Description;
            vs.SeasonID = season.SeasonID;
            vs.LeagueID = (season.SeasonID == 0) ? LeagueID : season.LeagueID;
            vs.AgeClassRuleID = season.AgeClassRuleID;
            vs.AgeClassRuleCustomDate = season.AgeClassRuleCustomDate;
            vs.AgeClassRules = GetAgeClassRules(season.AgeClassRuleID);
            vs.ScoringSchemeIDs = GetScoringSchemeIDs(SeasonID);

            //TODO:Finish this
            List<ViewScoringScheme> customScoringScheme = GetScoringSchemes(false, SwimomaticBusinessManager.ScoringEventType.Heat);

            vs.ScoringSchemesHeat = GetScoringSchemes(true, SwimomaticBusinessManager.ScoringEventType.Heat);
            vs.ScoringSchemesFinal = GetScoringSchemes(true, SwimomaticBusinessManager.ScoringEventType.Final);
            vs.ScoringSchemesConsolation = GetScoringSchemes(true, SwimomaticBusinessManager.ScoringEventType.Consolation);
            return vs;
        }

        //
        private List<int> GetScoringSchemeIDs(int SeasonID)
        {
            List<int> ScoringSchemeIDs = new List<int>();
            ScoringSchemeCollection scoringSchemes = BizMgr.GetScoringSchemesBySeasonID(SeasonID);
            foreach (ScoringScheme scoringScheme in scoringSchemes)
            {
                ScoringSchemeIDs.Add(scoringScheme.ScoringSchemeID);
            }
            return ScoringSchemeIDs;
        }

        /// <summary>
        /// Gets the scoring schemes used by USASwimming
        /// </summary>
        /// <param name="IsUSASwimming"></param>
        /// <param name="ScoringEventType"></param>
        /// <returns></returns>
        private List<ViewScoringScheme> GetScoringSchemes(bool IsUSASwimming, SwimomaticBusinessManager.ScoringEventType ScoringEventType)
        {
            ScoringSchemeCollection scoringSchemes = BizMgr.GetUSASwimmingScoringSchemes(IsUSASwimming, ScoringEventType);
            List<ViewScoringScheme> vsss = new List<ViewScoringScheme>();
            ViewScoringScheme vss = null;
            foreach (ScoringScheme scoringScheme in scoringSchemes)
            {
                vss = new ViewScoringScheme();
                vss.Description = scoringScheme.Description;
                vss.IndividualPoints = scoringScheme.IndividualPoints;
                vss.IsUSASwimming = scoringScheme.IsUSASwimming;
                vss.RelayPoints = scoringScheme.RelayPoints;
                vss.ScoringSchemeID = scoringScheme.ScoringSchemeID;
                vsss.Add(vss);
            }

            return vsss;
        }

        private List<ViewTeam> GetTeamSeasons(int SeasonID)
        {
            TeamCollection teams = BizMgr.GetTeamsBySeasonID(SeasonID);
            List<ViewTeam> vts = new List<ViewTeam>();
            ViewTeam vt = null;
            foreach (Team team in teams)
            {
                vt = new ViewTeam();
                vt.TeamName = team.TeamName;
                vt.Abbrev = team.Abbrev;
                vt.TeamNameAbbrev = team.TeamNameAbbrev;
                vt.LocationName = team.LocationName;
                vt.Address = team.Address;
                vt.PostalCode = team.PostalCode;
                vts.Add(vt);
            }
            return vts;
        }

        private List<ViewTeam> GetTeamLeagueRequests(int SeasonID)
        {
            List<ViewTeam> vts = new List<ViewTeam>();
            ViewTeam vt = null;
            TeamCollection teams = BizMgr.GetTeamLeagueRequestsBySeasonID(SeasonID);
            foreach (Team team in teams)
            {
                vt = new ViewTeam();
                vt.TeamNameAbbrev = team.TeamNameAbbrev;
                vt.LocationName = team.LocationName;
                vt.UserTeamID = team.UserTeamID;
                vt.TeamLeagueRequestID = team.TeamLeagueRequestID;
                vt.SeasonID = SeasonID;
                vts.Add(vt);
            }
            return vts;
        }

        private SelectList GetAgeClassRules(int AgeClassRuleID)
        {
            AgeClassRuleCollection regions = BizMgr.GetAgeClassRules();
            if (AgeClassRuleID > 0)
            {
                return new SelectList(regions, "AgeClassRuleID", "ShortDescription", AgeClassRuleID);
            }
            else
            {
                return new SelectList(regions, "AgeClassRuleID", "ShortDescription");
            }
        }
        #endregion
    }
}
