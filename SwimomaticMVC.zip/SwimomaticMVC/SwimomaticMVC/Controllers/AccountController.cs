﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using SwimomaticMVC.Models;
using SwimomaticMVC.Helpers;
using System.Configuration;
using Swimomatic.Entity;
using MvcReCaptcha;
using LAAF.Logger;

namespace SwimomaticMVC.Controllers
{
    public class AccountController : ControllerBase
    {

        public IFormsAuthenticationService FormsService { get; set; }

        protected override void Initialize(RequestContext requestContext)
        {
            try
            {
                if (FormsService == null) { FormsService = new FormsAuthenticationService(); }
                base.Initialize(requestContext);
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "ServerVariables=" + requestContext.HttpContext.Request.ServerVariables["ALL_HTTP"], "");
            }
        }

        // **************************************
        // URL: /Account/LogOn
        // **************************************

        public ActionResult LogOn()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LogOn(LogOnModel model, string returnUrl)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    SystemUser su = BizMgr.ValidateUser(model.UserName, model.Password);
                    if (su.SystemUserID > 0 && su.IsActive)
                    {
                        FormsService.SignIn(model.UserName, model.RememberMe);
                        SetCurrentUser(su);

                        if (!String.IsNullOrEmpty(returnUrl))
                        {
                            return Redirect(returnUrl);
                        }
                        else
                        {
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "The user name or password provided is incorrect.");
                    }
                }
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "UserName=" + model.UserName.ToString());
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        private void SetCurrentUser(SystemUser su)
        {
            try
            {
                this.CurrentUser = new CurrentUserBase(su);
                UserLeagueCollection uls = BizMgr.GetUserLeaguesBySystemUserID(su.SystemUserID);
                foreach (UserLeague ul in uls)
                {
                    League l = BizMgr.GetLeague(ul.LeagueID);
                    if (!this.CurrentUser.Leagues.Contains(l))
                    {
                        this.CurrentUser.Leagues.Add(l);
                    }
                }
                UserTeamCollection uts = BizMgr.GetUserTeamsBySystemUserID(su.SystemUserID);
                foreach (UserTeam ut in uts)
                {
                    Team t = BizMgr.GetTeam(ut.TeamID);
                    if (!this.CurrentUser.Teams.Contains(t))
                    {
                        this.CurrentUser.Teams.Add(t);
                    }
                }
                UserSwimmerCollection uss = BizMgr.GetUserSwimmersBySystemUserID(su.SystemUserID);
                foreach (UserSwimmer us in uss)
                {
                    Swimmer s = BizMgr.GetSwimmer(us.SwimmerID);
                    if (!this.CurrentUser.Swimmers.Contains(s))
                    {
                        this.CurrentUser.Swimmers.Add(s);
                    }
                }
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "UserID=" + su.SystemUserID.ToString());
            }
        }
        // **************************************
        // URL: /Account/LogOff
        // **************************************

        public ActionResult LogOff()
        {
            try
            {
                FormsService.SignOut();
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "UserID=" + this.CurrentUser.SystemUserID.ToString());
            }
            return RedirectToAction("Index", "Home");
        }

        // **************************************
        // URL: /Account/Register
        // **************************************

        public ActionResult Register()
        {
            ViewBag.PasswordFormat = AccountValidation.PasswordFormatMessage;
            return View();
        }

        [CaptchaValidator]
        [HttpPost]
        public ActionResult Register(RegisterModel model, bool captchaValid)
        {
            string successMessage = "";
            try
            {
                if (captchaValid)
                {
                    if (ModelState.IsValid)
                    {
                        MembershipCreateStatus createStatus = BizMgr.CreateUser(model.UserName, model.Password, model.Email);
                        if (createStatus == MembershipCreateStatus.Success)
                        {
                            successMessage = string.Format(BizMgr.ReadResourceValue("Email", "RegistrationSuccessMessage"), model.Email);
                        }
                        else
                        {
                            ModelState.AddModelError("", AccountValidation.ErrorCodeToString(createStatus));
                            ViewBag.PasswordFormat = AccountValidation.PasswordFormatMessage;
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("Captcha", "You did not enter the Captcha values correctly. Please try again.");
                    ViewBag.PasswordFormat = AccountValidation.PasswordFormatMessage;
                }
                ViewData["SuccessMessage"] = successMessage;
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "Email=" + model.Email);
            }
            return View(model);
        }
        //public ActionResult Register(RegisterModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        // Attempt to register the user
        //        MembershipCreateStatus createStatus = MembershipService.CreateUser(model.UserName, model.Password, model.Email);

        //        if (createStatus == MembershipCreateStatus.Success)
        //        {
        //            FormsService.SignIn(model.UserName, false /* createPersistentCookie */);
        //            return RedirectToAction("Index", "Home");
        //        }
        //        else
        //        {
        //            ModelState.AddModelError("", AccountValidation.ErrorCodeToString(createStatus));
        //        }
        //    }

        //    // If we got this far, something failed, redisplay form
        //    ViewBag.PasswordLength = MembershipService.MinPasswordLength;
        //    return View(model);
        //}

        public ActionResult ConfirmRegistration(string id)
        {
            try
            {
                Guid registrationKey = new Guid(id);
                SystemUser su = BizMgr.ConfirmRegistration(registrationKey);
                if (su.SystemUserID > 0)
                {
                    FormsService.SignIn(su.Email, false /* createPersistentCookie */);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "registrationKey=" + id);
            }
            return new EmptyResult();
        }
        // **************************************
        // URL: /Account/ChangePassword
        // **************************************

        //[Authorize]
        //public ActionResult ChangePassword()
        //{
        //    ViewBag.PasswordLength = MembershipService.MinPasswordLength;
        //    return View();
        //}

        [Authorize]
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (BizMgr.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword))
                    {
                        return RedirectToAction("ChangePasswordSuccess");
                    }
                    else
                    {
                        ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                    }
                }

                // If we got this far, something failed, redisplay form
                ViewData["PasswordFormat"] = ConfigurationManager.AppSettings["MinPasswordLength;"];
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "", "Password=" + model.NewPassword);
            }
            return View(model);
        }

        // **************************************
        // URL: /Account/ChangePasswordSuccess
        // **************************************

        public ActionResult ChangePasswordSuccess()
        {
            return View();
        }

    }
}
