﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SwimomaticMVC.Models;
using Swimomatic.Entity;
using SwimomaticBusinessLib;
using LAAF.Logger;

namespace SwimomaticMVC.Controllers
{
    public class ResultController : ControllerBase
    {
        #region Action Methods
        public ActionResult Index(int HeatSheetEventID)
        {
            ViewData["HeatSheetEvent"] = GetHeatSheetEvent(HeatSheetEventID);
            ViewData["Heats"] = GetHeats(HeatSheetEventID);
            return View();
        }
        public ActionResult SaveHeatSheetEventResults(int HeatSheetEventID, string ET, string Split, string DQ)
        {
            System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();

            List<ViewHeatSheetEventResult> rETs = new List<ViewHeatSheetEventResult>();
            rETs = js.Deserialize<List<ViewHeatSheetEventResult>>(ET);

            List<ViewHeatSheetEventResult> rSplits = new List<ViewHeatSheetEventResult>();
            rSplits = js.Deserialize<List<ViewHeatSheetEventResult>>(Split);

            List<ViewHeatSheetEventResult> rDQs = new List<ViewHeatSheetEventResult>();
            rDQs = js.Deserialize<List<ViewHeatSheetEventResult>>(DQ);

            SaveResults(HeatSheetEventID, rETs, rSplits, rDQs);

            ViewData["Heats"] = GetHeats(HeatSheetEventID);
            return PartialView("SwimMeetResults");
        }
        #endregion

        #region Private Methods
        private ViewHeatSheetEvent GetHeatSheetEvent(int HeatSheetEventID)
        {
            ViewHeatSheetEvent vhse = new ViewHeatSheetEvent();
            HeatSheetEvent hse = BizMgr.GetHeatSheetEvent(HeatSheetEventID);
            vhse.HeatSheetEventID = hse.HeatSheetEventID;
            vhse.HeatSheetID = hse.HeatSheetID;
            vhse.Sequence = hse.Sequence;
            vhse.Description = hse.Description;
            return vhse;
        }

        private void SaveResults(int HeatSheetEventID, List<ViewHeatSheetEventResult> rETs, List<ViewHeatSheetEventResult> rSplits, List<ViewHeatSheetEventResult> rDQs)
        {
            //consolidate 3 lists into one list of Results
            List<Result> results = new List<Result>();
            Result result = null;

            //get stroke to determine whether it's a relay or not
            Stroke stroke = BizMgr.GetStrokeByHeatSheetEventID(HeatSheetEventID);
            bool IsRelay = stroke.IsRelay;

            foreach (ViewHeatSheetEventResult vr in rETs)
            {
                if (IsRelay)
                {
                    //All legs of one relay get the same ET...
                    HeatSwimmerCollection relayTeammates = BizMgr.GetRelayTeammates(vr.HeatSwimmerID);
                    //create additional results for relay teammates
                    foreach (HeatSwimmer hs in relayTeammates)
                    {
                        result = new Result();
                        result.HeatSwimmerID = hs.HeatSwimmerID;
                        result.ElapsedTime = vr.ElapsedTime;
                        results.Add(result);
                    }
                }
                //create ET result for current swimmer
                result = new Result();
                result.HeatSwimmerID = vr.HeatSwimmerID;
                result.ElapsedTime = vr.ElapsedTime;
                results.Add(result);
            }

            foreach (ViewHeatSheetEventResult vr in rSplits)
            {
                var tempResult = results.Where(r => r.HeatSwimmerID == vr.HeatSwimmerID).FirstOrDefault();
                if (tempResult == null)
                {
                    result = new Result();
                    result.HeatSwimmerID = vr.HeatSwimmerID;
                    result.Split = vr.Split;
                    results.Add(result);
                }
                else
                {
                    result = tempResult;
                    result.Split = vr.Split;
                }
            }

            foreach (ViewHeatSheetEventResult vr in rDQs)
            {
                var tempResult = results.Where(r => r.HeatSwimmerID == vr.HeatSwimmerID).FirstOrDefault();
                if (IsRelay)
                {
                    HeatSwimmerCollection relayTeammates = BizMgr.GetRelayTeammates(tempResult.HeatSwimmerID);
                    //create additional results for relay teammates
                    foreach (HeatSwimmer hs in relayTeammates)
                    {
                        var teammateResult = results.Where(r => r.HeatSwimmerID == hs.HeatSwimmerID).FirstOrDefault();
                        teammateResult.Disqualified = (teammateResult!=null);
                    }
                }
                if (tempResult == null)
                {
                    result = new Result();
                    result.HeatSwimmerID = vr.HeatSwimmerID;
                    result.Disqualified = true; //only DQ that = true are included in the list
                    results.Add(result);
                }
                else
                {
                    result = tempResult;
                    result.Disqualified = true;
                }
            }
            BizMgr.SaveResults(HeatSheetEventID, results, this.CurrentUser.SystemUserID);
        }

        #endregion

    }
}
