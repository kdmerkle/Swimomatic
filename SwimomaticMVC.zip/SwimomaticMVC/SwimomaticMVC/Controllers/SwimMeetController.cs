﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Swimomatic.Entity;
using SwimomaticBusinessLib;
using System.Web.UI.WebControls;
using SwimomaticMVC.Models;
using LAAF.Logger;

namespace SwimomaticMVC.Controllers
{
    public class SwimMeetController : ControllerBase
    {
        #region Action Methods
        public ActionResult Index()
        {
            try
            {
                ViewData["Controller"] = "SwimMeet";
                ViewData["SwimMeets"] = GetSwimMeets(base.CurrentUser.SystemUserID);
                ViewData["Regions"] = GetRegions(0);
                List<ViewLocation> vls = GetViewLocations(base.CurrentUser.SystemUserID);
                ViewData["Locations"] = vls;
                ViewData["Leagues"] = GetViewLeagues(base.CurrentUser.SystemUserID);
                ViewData["PoolConfigs"] = GetPoolConfigs(vls);
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }
            return View();
        }

        public ActionResult SaveSwimMeet(int SwimMeetID, DateTime StartDate, DateTime EndDate, string Description, int LocationID, int LeagueID, int SeasonID, string TeamIDs)
        {
            try
            {
                //Save SwimMeet
                SwimMeet swimMeet = new SwimMeet();
                swimMeet.SwimMeetID = SwimMeetID;
                swimMeet.Description = Description;
                swimMeet.StartDate = StartDate;
                swimMeet.EndDate = EndDate;
                swimMeet.LocationID = LocationID;
                swimMeet.SeasonID = SeasonID;
                swimMeet.SwimMeetID = BizMgr.SaveSwimMeet(swimMeet, base.CurrentUser.SystemUserID);

                //Delete existing SwimMeetTeams
                BizMgr.DeleteSwimMeetTeamsBySwimMeetID(swimMeet.SwimMeetID);

                //Save SwimMeetTeams
                string[] arrTeamIDs = TeamIDs.Split(new char[] { '|' });
                SwimMeetTeam smt = null;
                for (int i = 0; i < arrTeamIDs.Length; i++)
                {
                    smt = new SwimMeetTeam();
                    smt.SwimMeetID = swimMeet.SwimMeetID;
                    smt.TeamID = int.Parse(arrTeamIDs[i]);
                    BizMgr.SaveSwimMeetTeam(smt);
                }
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }

            ViewData["SwimMeets"] = GetSwimMeets(base.CurrentUser.SystemUserID);
            return PartialView("SwimMeets");
        }

        public ActionResult DeleteSwimMeet(int SwimMeetID)
        {
            try
            {
                BizMgr.DeleteSwimMeet(SwimMeetID);
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }

            ViewData["SwimMeets"] = GetSwimMeets(base.CurrentUser.SystemUserID);
            return PartialView("SwimMeets");
        }

        public ActionResult GetTeams(int SeasonID)
        {
            try
            {
                ViewTeams vts = new ViewTeams();
                vts.ViewTeamList = GetViewTeamList(SeasonID);
                ViewData["Teams"] = vts;
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }
            return PartialView("Teams");
        }

        public ActionResult GetSeasons(int LeagueID)
        {
            try
            {
                ViewSeasons vss = new ViewSeasons();
                vss.ViewSeasonList = GetViewSeasonList(LeagueID);
                ViewData["Seasons"] = vss;
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }
            return PartialView("Seasons");
        }

        /// <summary>
        /// Gets the list of all Cities from all the Locations in the given region
        /// </summary>
        /// <param name="RegionID"></param>
        /// <returns></returns>
        public JsonResult GetCities(int RegionID)
        {
            List<SwimomaticBusinessLib.ListItem> itemList = null;
            try
            {
                LocationCollection locations = BizMgr.GetLocationsByRegionID(RegionID);
                var ls = locations.GroupBy(l => l.City.ToUpper()).Select(l => l.First());
                itemList = SwimomaticBusinessLib.Utility.GetListItemsFromLAAFCollection(ls, "City", "City", "Cities");
            }
            catch (Exception ex)
            {
                LogController.LogError(ex, LogEntryType.NormalError, "", "", "SystemUserID=" + base.CurrentUser.SystemUserID.ToString(), "");
            }
            return this.Json(itemList);
        }

        #endregion

        #region Private Methods

        private ViewSwimMeets GetSwimMeets(int SystemUserID)
        {
            ViewSwimMeets vsms = new ViewSwimMeets();
            ViewSwimMeet vsm;
            SwimMeetCollection swimMeets = BizMgr.GetSwimMeetsBySystemUserID(SystemUserID);
            foreach (SwimMeet swimMeet in swimMeets)
            {
                vsm = new ViewSwimMeet();
                vsm.CanEdit = (swimMeet.EndDate > DateTime.Today);
                vsm.HasResults = swimMeet.HasResults;
                vsm.Description = swimMeet.Description;
                vsm.EndDate = swimMeet.EndDate;
                vsm.StartDate = swimMeet.StartDate;
                vsm.SeasonID = swimMeet.SeasonID;
                vsm.SeasonDescription = swimMeet.SeasonDescription;
                vsm.LeagueDescription = swimMeet.LeagueDescription;
                vsm.LocationID = swimMeet.LocationID;
                vsm.LocationName = swimMeet.LocationName;
                vsm.SwimMeetID = swimMeet.SwimMeetID;

                TeamCollection teams = BizMgr.GetTeamsBySwimMeetID(swimMeet.SwimMeetID);
                foreach (Team team in teams)
                {
                    vsm.Teams += team.TeamNameAbbrev + ", ";
                }
                vsm.Teams = vsm.Teams.TrimEnd(new char[] { ' ', ',' });
                vsms.ViewSwimMeetList.Add(vsm);
            }
            return vsms;
        }

        /// <summary>
        /// Returns all the teams with a current or future TeamSeason record containing the given LeagueID
        /// </summary>
        /// <param name="SeasonID"></param>
        /// <returns></returns>
        private List<ViewTeam> GetViewTeamList(int SeasonID)
        {
            List<ViewTeam> vts = new List<ViewTeam>();
            ViewTeam vt;
            TeamCollection teams = BizMgr.GetTeamsBySeasonID(SeasonID);
            foreach (Team t in teams)
            {
                vt = new ViewTeam();
                vt.Abbrev = t.Abbrev;
                vt.TeamID = t.TeamID;
                vt.TeamName = t.TeamName;
                vts.Add(vt);
            }
            return vts;
        }
        /// <summary>
        /// Returns all the Leagues that the user is admin of, or leagues which the user's teams are members of
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private List<ViewLeague> GetViewLeagues(int SystemUserID)
        {
            LeagueCollection leagues = BizMgr.GetEligibleLeaguesBySystemUserID(SystemUserID);
            return GetViewLeaguesFromLeagues(leagues);
        }

        private List<ViewSeason> GetViewSeasonList(int LeagueID)
        {
            List<ViewSeason> vsl = new List<ViewSeason>();
            ViewSeason vs = null;
            List<Season> seasons = BizMgr.GetCurrentSeasonsByLeagueID(LeagueID);
            foreach (Season s in seasons)
            {
                vs = new ViewSeason();
                vs.Description = s.Description;
                vs.EndDate = s.EndDate;
                vs.LeagueID = s.LeagueID;
                vs.SeasonID = s.SeasonID;
                vs.StartDate = s.StartDate;
                vsl.Add(vs);
            }
            return vsl;
        }

        private List<ViewLeague> GetViewLeaguesFromLeagues(LeagueCollection leagues)
        {
            List<ViewLeague> vls = new List<ViewLeague>();
            ViewLeague vl;
            foreach (League l in leagues)
            {
                vl = new ViewLeague();
                vl.LeagueDescription = l.Description;
                vl.LeagueName = l.LeagueName;
                vl.LeagueID = l.LeagueID;
                vl.RegionAbbrev = l.RegionAbbrev;
                vls.Add(vl);
            }
            return vls;
        }

        private List<ViewPoolConfig> GetPoolConfigs(List<ViewLocation> viewLocations)
        {
            List<ViewPoolConfig> vpcs = new List<ViewPoolConfig>();
            ViewPoolConfig vpc;
            List<int> locationIDs = new List<int>();
            foreach (ViewLocation vl in viewLocations)
            {
                locationIDs.Add(vl.LocationID);
            }
            PoolConfigCollection pcs = BizMgr.GetPoolConfigsByLocationIDList(locationIDs);
            foreach (PoolConfig pc in pcs)
            {
                vpc = new ViewPoolConfig();
                vpc.LaneCount = pc.LaneCount;
                vpc.LocationName = pc.LocationName;
                vpc.LengthDescription = pc.LengthDescription;
                vpc.PoolDescription = pc.PoolDescription;
                vpc.UOMAbbrev = pc.UOMAbbrev;
                vpcs.Add(vpc);
            }
            return vpcs;
        }
        #endregion
    }
}
